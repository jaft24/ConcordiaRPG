/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.concordiarpg;

/**
 *
 * @author Office Heros
 */
public class MainClass {

    /**
     * As it names indicates it is the main class...
     * We know iy doesn't have as it was suppose to 
     * But as you can see all of the JFrames are main so that's why
     */
    public static void main(String[] args) {
       // TODO code application logic here
        
      LoginPage Lp = new LoginPage();
      Lp.setVisible(true); 
       
      // HomePage Hp = new HomePage();
      // Hp.setVisible(true);
        
       // StudyConcordia Sc = new StudyConcordia();
       // Sc.setVisible(true);
       
      // CampusMap Cm = new CampusMap();
       //Cm.setVisible(true);
       
       // CommonQandA Cqa = new CommonQandA();
       // Cqa.setVisible(true);
       
      // Assessment ass = new Assessment();
       // ass.setVisible(true);
       
       
        //StartPage sp = new StartPage();
        //sp.setVisible(true);
    
 
    }
    
}
