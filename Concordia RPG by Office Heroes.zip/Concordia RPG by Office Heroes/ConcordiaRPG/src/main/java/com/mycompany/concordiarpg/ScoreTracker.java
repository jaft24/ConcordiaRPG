/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.concordiarpg;

/**
 *
 * @author Office Heros
 */
public class ScoreTracker {
    
    // variable declaration begins
    
    /*
       Except for the variable score, the rest are information we obtain from the form.
       The variable store is a static variable that tracks the questions the user answered correct.
    */
    public static double score = 0;
    
 
}
